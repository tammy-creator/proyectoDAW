<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      
      <?php if(auth()->user()->roles()->first()->id == PR_ROL_USUARIO_ID): ?>   
        <div class="row justify-content-md-center">
          <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="card card-stats">
              <div class="card-header card-header-info card-header-icon">
                <div class="card-icon">
                  <i class="material-icons">person</i>
                </div>
                <p class="card-category">Bienvenido</p>
                <h3 class="card-title"><span><?php echo e(auth()->user()->name); ?></span></h3>
              </div>
              <div class="card-footer">
                <div class="stats">
                  <i class="material-icons">face</i>
                  <a href="<?php echo e(route('profile.edit')); ?>"> Ir a mi perfil... </a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="card card-stats">
              <div class="card-header card-header-success card-header-icon">
                <div class="card-icon">
                  <i class="material-icons">store</i>
                </div>
                <p class="card-category">Horas bono</p>
                <h3 class="card-title"><span><?php echo e($bonoHoras); ?></span></h3>
              </div>
              <div class="card-footer">
                <div class="stats">
                  <i class="material-icons">store</i>
                  <a href="<?php echo e(route('tienda.index')); ?>"> Comprar más... </a>
                </div>
              </div>
            </div>
          </div>
          <?php if(auth()->user()->terapeuta_id != null): ?>
            <div class="col-lg-4 col-md-4 col-sm-4">
              <div class="card card-stats">
                <div class="card-header card-header-danger card-header-icon">
                  <div class="card-icon">
                    <i class="material-icons">pending_actions</i>
                  </div>
                  <p class="card-category">Próxima cita</p>
                  <?php if($proxEvento == null): ?>
                    <h3 class="card-title"><span> <strong>No tiene citas</strong>  </span></h3>
                  <?php else: ?>
                    <h3 class="card-title"><span> <strong>Día:</strong>  <?php echo e(date("d-m", strtotime($proxEvento->fecha))); ?> a las <?php echo e(date("h", strtotime($proxEvento->hora_inicio))); ?> h.</span></h3>
                  <?php endif; ?>
                </div>
                <div class="card-footer">
                  <div class="stats">
                    <i class="material-icons">date_range</i>
                    <a href="<?php echo e(route('evento.index')); ?>"> Ver calendario </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        <?php endif; ?>
      <?php endif; ?>

      <?php if(auth()->user()->roles()->first()->id == PR_ROL_ADMINISTRADOR_ID): ?>     
        <div class="row">
          <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="card card-stats">
              <div class="card-header card-header-warning card-header-icon">
                <div class="card-icon">
                  <i class="material-icons">person</i>
                </div>
                <p class="card-category">Usuarios Registrados</p>
                <h3 class="card-title">
                  <span><?php echo e($countUsers); ?></span>
                </h3>
              </div>
              <div class="card-footer">
                <div class="stats">
                  <i class="material-icons">content_paste</i>
                  <a href="<?php echo e(route('users.index')); ?>">Saber más...</a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="card card-stats">
              <div class="card-header card-header-success card-header-icon">
                <div class="card-icon">
                  <i class="material-icons">store</i>
                </div>
                <p class="card-category">Ventas Totales</p>
                <h3 class="card-title"><span><?php echo e($totalVendido); ?> €</span></h3>
              </div>
              <div class="card-footer">
                <div class="stats">
                  <i class="material-icons">store</i>
                  <a href="<?php echo e(route('ventas.index')); ?>"> Ver ventas... </a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="card card-stats">
              <div class="card-header card-header-danger card-header-icon">
                <div class="card-icon">
                  <i class="material-icons">pending_actions</i>
                </div>
                <p class="card-category">Citas Hoy</p>
                <h3 class="card-title"><span><?php echo e($countEventos); ?></span></h3>
              </div>
              <div class="card-footer">
                <div class="stats">
                  <i class="material-icons">date_range</i>
                  <a href="<?php echo e(route('evento.index')); ?>"> Ver calendario </a>
                </div>
              </div>
            </div>
          </div>          
        </div>
      <?php endif; ?>
      <?php if(auth()->user()->roles()->first()->id == PR_ROL_TERAPEUTA_ID): ?>     
      <div class="row">
        <div class="col-lg-5 col-md-6 col-sm-6">
          <div class="card card-stats">
            <div class="card-header card-header-warning card-header-icon">
              <div class="card-icon">
                <i class="material-icons">person</i>
              </div>
              <p class="card-category">Mis pacientes</p>
              <h3 class="card-title">
                <span><?php echo e($countUserTerap); ?></span>
              </h3>
            </div>
            <div class="card-footer">
              <div class="stats">
                <i class="material-icons">content_paste</i>
                <a href="<?php echo e(route('users.index')); ?>">Saber más...</a>
              </div>
            </div>
          </div>
        </div>
        
        <div class="col-lg-5 col-md-6 col-sm-6">
          <div class="card card-stats">
            <div class="card-header card-header-danger card-header-icon">
              <div class="card-icon">
                <i class="material-icons">pending_actions</i>
              </div>
              <p class="card-category">Citas Hoy</p>
              <h3 class="card-title"><span><?php echo e($countEventos); ?></span></h3>
            </div>
            <div class="card-footer">
              <div class="stats">
                <i class="material-icons">date_range</i>
                <a href="<?php echo e(route('evento.index')); ?>"> Ver calendario </a>
              </div>
            </div>
          </div>
        </div>
        
      </div>
    <?php endif; ?>
      
      <div class="row">
        <div class="col-sm-6">
          <div class="card">
            <div class="card-header card-header-tabs card-header-primary">
              <div class="nav-tabs-navigation">
                <div class="nav-tabs-wrapper">
                  <span class="nav-tabs-title">Últimas Notificaciones:</span>
                  <ul class="nav nav-tabs justify-content-md-center" data-tabs="tabs">
                    <li class="nav-item ">
                      <a class="nav-link active" href="#eventos" data-toggle="tab">
                        <i class="material-icons">event</i> Nuevas Citas
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <?php if(auth()->user()->roles()->first()->id != PR_ROL_USUARIO_ID): ?>
                    <li class="nav-item">
                      <a class="nav-link" href="#usuarios" data-toggle="tab">
                        <i class="material-icons">face</i> Nuevos Usuarios
                        <div class="ripple-container"></div>
                      </a>
                    </li> 
                    <?php endif; ?>                   
                  </ul>
                </div>
              </div>
            </div>
            <div class="card-body">
              <div class="tab-content">
                <div class="tab-pane active" id="eventos">
                  <table class="table">
                    <tbody>                
                      <?php $__currentLoopData = $eventoNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->type == 'App\Notifications\EventoNotification'): ?>
                          <tr>
                            <td> <span class="badge badge-info">Nueva Cita:</span>  <?php echo e($item->data['user_name']); ?> para el día <?php echo e(date("d-m-Y", strtotime($item->data['fecha']))); ?> a las <?php echo e($item->data['hora_inicio']); ?></td>                  
                            
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            <td class="td-actions text-right">
                              <a href="<?php echo e(route('markAsRead')); ?>" class="btn btn-info btn-link btn-sm">                          
                                <i class="material-icons">done_all</i> 
                                <span><strong> Marcar Leídos </strong></span> 
                              </a>
                            </td>
                          </tr>
                    </tbody>
                  </table>
                </div>
                <div class="tab-pane" id="usuarios">
                  <table class="table">
                    <tbody>
                        <?php $__currentLoopData = $eventoNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($item->type == 'App\Notifications\UserNotification'): ?>
                          <tr>
                          <td>Nuevo usuario registrado: <?php echo e($item->data['user_name']); ?></td>                  
                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                        <td class="td-actions text-right">
                          <a href="<?php echo e(route('markAsRead')); ?>" class="btn btn-info btn-link btn-sm">                          
                            <i class="material-icons">done_all</i> 
                            <span><strong> Marcar Leídos </strong></span> 
                          </a>
                        </td>  
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php if(auth()->user()->roles()->first()->id == PR_ROL_ADMINISTRADOR_ID): ?>   
          <div class="col-sm-6">
            <div class="card">
              <div class="card-header card-header-warning">
                <h4 class="card-title">Terapeutas</h4>              
              </div>
              <div class="card-body table-responsive">
                <table class="table table-hover">
                  <thead class="text-warning">
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Teléfono</th>
                    <th>Email</th>
                    <th>Pacientes</th>
                  </thead>
                  <tbody>                  
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($role->id == PR_ROL_TERAPEUTA_ID): ?>
                          <tr>
                            <td><?php echo e($user->id); ?></td>
                            <td><?php echo e($user->name); ?></td>                                                     
                            <td><?php echo e($user->telefono); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($countUserTerap); ?></td>
                          </tr>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        <?php endif; ?>
        <?php if(auth()->user()->roles()->first()->id == PR_ROL_TERAPEUTA_ID): ?>
          <div class="col-sm-6">
            <div class="card">
              <div class="card-header card-header-warning">
                <h4 class="card-title">Mis Pacientes</h4>              
              </div>
              <div class="card-body table-responsive">
                <table class="table table-hover">
                  <thead class="text-warning">
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Apellidos</th>
                    <th>Teléfono</th>
                    <th>Email</th>
                  </thead>
                  <tbody>                  
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($role->id == PR_ROL_USUARIO_ID && $user->terapeuta_id == auth()->user()->id): ?>
                          <tr>
                            <td><?php echo e($user->id); ?></td>
                            <td><?php echo e($user->name); ?></td>  
                            <td><?php echo e($user->apellidos); ?></td>                                                   
                            <td><?php echo e($user->telefono); ?></td>
                            <td><?php echo e($user->email); ?></td>                            
                          </tr>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        <?php endif; ?>
        <?php if(auth()->user()->roles()->first()->id == PR_ROL_USUARIO_ID): ?>
          <div class="col-sm-6" style="width: 50rem;">
            <div class="card">
              <div class="card-header card-header-warning">
                <h4 class="card-title">Mis Compras</h4>              
              </div>
              <div class="card-body table-responsive">
                <table class="table table-hover">
                  <thead class="text-warning">
                    <th>Fecha</th>
                    <th>Producto</th>
                    <th>Precio</th>
                    <th>Cantidad</th>                    
                  </thead>
                  <tbody>                  
                    <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($venta->user_id == auth()->user()->id): ?>
                        <tr>
                          <td><?php echo e(date("d-m-Y", strtotime($venta->created_at))); ?></td>
                          <td><?php echo e($venta->producto_name); ?></td>  
                          <td><?php echo e($venta->precio); ?></td>                                                   
                          <td><?php echo e($venta->cantidad); ?></td>
                        </tr>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        <?php endif; ?>
      </div>
    </div> 
  </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.main', ['activePage' => 'dashboard', 'titlePage' => __('Dashboard')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto\proyecto\resources\views/home.blade.php ENDPATH**/ ?>