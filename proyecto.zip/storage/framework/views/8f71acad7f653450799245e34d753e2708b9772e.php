
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-primary">
                        <div class="card-title">Permisos</div>
                        <p class="card-category">Vista detallada del permiso <?php echo e($permission->name); ?></p>
                    </div>
                    <!--body-->
                    <div class="card-body">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success" role="success">
                            <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="row">
                        <div class="col-md-6">
                            <div class="card card-user">
                            <div class="card-body">
                                <p class="card-text">
                                <div class="author">
                                    <a href="#">
                                    <img src="<?php echo e(asset('/material/img/astronauta.jpg')); ?>" alt="image" class="avatar">
                                    <h5 class="title mt-3"><?php echo e($permission->name); ?></h5>
                                    </a>                                    
                                </div>
                                </p>
                                <div class="card-description">
                                <?php echo e($permission->descripcion); ?>

                                </div>
                            </div>
                            <div class="card-footer">                                
                                <div class="button-container">
                                    <a href="<?php echo e(route('permissions.index')); ?>" class="btn btn-primary mr-3"> Volver </a>
                                    <a href="<?php echo e(route('permissions.edit', $permission->id)); ?>" class="btn btn-primary">Editar</a>
                                </div>
                            </div>                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
                    
<?php echo $__env->make('layouts.main', ['activePage' => 'permissions', 'titlePage' => 'Detalles del permiso'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto\proyecto\resources\views/permissions/show.blade.php ENDPATH**/ ?>