
<?php $__env->startSection('content'); ?>
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="row">
              <div class="col-md-12">
                <div class="card">

                  <?php if(session('success')): ?>
                  <div class="alert alert-success" role="success">
                    <?php echo e(session('success')); ?>

                  </div>
                  <?php endif; ?>
                  <?php if(session('error')): ?>
                  <div class="alert alert-danger" role="danger">
                    <?php echo e(session('error')); ?>

                  </div>
                  <?php endif; ?>

                  <div class="alert alert-danger" id="error" style="display:none"></div>
                  <div class="alert alert-success" id="message" style="display:none"></div>

                  <div class="card-header card-header-primary">
                    <h4 class="card-title">Productos</h4>
                    <p class="card-category">Productos registrados</p>
                  </div>
                  <div class="card-body">
                    <div class="row">
                      <div class="col-12 text-right">
                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_create')): ?>
                        <a href="<?php echo e(route('productos.create')); ?>" class="btn btn-sm btn-primary">Añadir producto</a>
                      <?php endif; ?> 
                      </div>
                    </div>
                    <div class="table-responsive">
                      <table class="table">
                        <thead class="text-primary">
                            <th>ID</th>
                            <th>Imagen</th>
                            <th>Nombre</th>
                            <th>Descripción</th>                            
                            <th>Precio</th>                           
                            <th class="text-right">Acciones</th>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($producto->id); ?></td>
                                <td><img width="50" src="<?php echo e($producto->imageSrc); ?>" alt="imagen producto" /></td>
                                <td><?php echo e($producto->name); ?></td>
                                <td><?php echo e($producto->descripcion); ?></td>
                                <td><?php echo e($producto->precio); ?></td>                                                               
                              
                                <td class="td-actions text-right">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('producto_show')): ?> 
                                  <a href="<?php echo e(route('productos.show', $producto->id)); ?>" class="btn btn-info"><i class="material-icons">visibility</i></a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('producto_edit')): ?>
                                  <a href="<?php echo e(route('productos.edit', $producto->id)); ?>" class="btn btn-warning"><i class="material-icons">edit</i></a>
                                <?php endif; ?> 
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('producto_destroy')): ?>
                                  <button class="btn btn-danger modal_link" type="submit" rel="tooltip" data-id="<?php echo e($producto->id); ?>">
                                    <i class="material-icons">close</i>
                                  </button>
                                <?php endif; ?> 
                              </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div class="card-footer mr-auto">
                    <?php echo e($productos->links()); ?> 
                  </div>

                  
                  <div id="confirm" class="modal" tabindex="-1" role="dialog">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Eliminar Producto</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <p>¿Estas seguro de eliminar el producto?</p>
                        </div>
                        <div class="modal-footer">
                          <button id="btnConfirm" type="button" class="btn btn-primary">Eliminar</button>
                          <button type="button" class="btn btn-secondary" data-dismiss="modal" >Cancelar</button>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('bottomJs'); ?>
<script>
  $(document).on('click',".modal_link",function(){
    $('#error').text('').hide();
    $('#message').text('').hide();
    $("#confirm").modal('show');
    $('#btnConfirm').data('id-delete', $(this).data('id'));
  });
    $(document).on('click',"#btnConfirm",function(){                
              
              let producto_id = $(this).data('id-delete');
              
              let urlDelete = "<?php echo e(url('productos/:id')); ?>".replace(":id", producto_id);
              
              $.ajax(urlDelete, {
                method: 'delete',
                data: {
                  _token: "<?php echo e(csrf_token()); ?>"
                }
              }).done(function(res) {
                $('#confirm').modal('hide');
                if(res['status'] === undefined) {
                  $('#error').text("Error interno borrando producto").show();
                  
                  return;
                }
                if(res.status == 1) {
                  $('#message').text(res.message).show();
                  $('#row-id-' + producto_id).remove()
                }
                else {
                  $('#error').text(res.message).show();
                }
               
              }).fail(function(xhr) {
                console.error(xhr);
              });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['activePage' => 'productos', 'titlePage' => 'Productos'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto\proyecto\resources\views/productos/index.blade.php ENDPATH**/ ?>