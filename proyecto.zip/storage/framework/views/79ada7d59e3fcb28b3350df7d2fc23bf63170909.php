

<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="list-group">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item"><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
          <?php endif; ?>
          <form method="post" action="<?php echo e(route('productos.update', $producto->id)); ?>" class="form-horizontal">
            <?php echo csrf_field(); ?>           
            <?php echo method_field('PUT'); ?>
            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Producto')); ?></h4>
                <p class="card-category"><?php echo e(__('Modificar datos')); ?></p>
              </div>

              <div class="card-body ">
                <div class="row">
                  <label for="name" class="col-sm-2 col-form-label"><?php echo e(__('Nombre')); ?></label>
                  <div class="col-sm-7">
                    <input class="form-control" name="name" type="text" value="<?php echo e(old('name', $producto->name)); ?>" autofocus/>                      
                    <?php if($errors->has('name')): ?>
                      <span class="error text-danger" for="input-name"><?php echo e($errors->first('name')); ?></span>
                    <?php endif; ?>                  
                  </div>
                </div>

                <div class="row">
                  <label for="precio" class="col-sm-2 col-form-label"><?php echo e(__('Precio')); ?></label>
                  <div class="col-sm-7">
                    <input class="form-control" name="precio" type="text" value="<?php echo e(old('precio', $producto->precio)); ?>"/>                      
                    <?php if($errors->has('precio')): ?>
                      <span class="error text-danger" for="input-precio"><?php echo e($errors->first('precio')); ?></span>
                    <?php endif; ?>
                  </div>
                </div>

                <div class="row">
                  <label for="descripcion" class="col-sm-2 col-form-label"><?php echo e(__('Descripción')); ?></label>
                  <div class="col-sm-7">
                    <input class="form-control" rows="3" name="descripcion" type="text" value="<?php echo e(old('descripcion', $producto->descripcion)); ?>"/>                      
                    <?php if($errors->has('descripcion')): ?>
                      <span class="error text-danger" for="input-descripcion"><?php echo e($errors->first('descripcion')); ?></span>
                    <?php endif; ?>
                  </div>
                </div>

                <div class="fileinput fileinput-new">                  
                    <div class="col-sm-7 mt-3">
                        <label for="foto" class="col-sm-2 col-form-label">Imagen</label>
                        <input type="file" class="form-control-file hidden" name="foto" id="foto" accept="image/*">
                    </div>                
                </div> 

              <div class="card-footer ml-auto mr-auto">
                <button type="submit" class="btn btn-primary"><?php echo e(__('Actualizar Producto')); ?></button>
                <a href="<?php echo e(route('productos.index')); ?>" class="btn btn-primary mr-3"> Volver </a>
              </div>
            </div>
          </form>
        </div>
      </div>      
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['activePage' => 'productos', 'titlePage' => __('Editar producto')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto\proyecto\resources\views/productos/edit.blade.php ENDPATH**/ ?>