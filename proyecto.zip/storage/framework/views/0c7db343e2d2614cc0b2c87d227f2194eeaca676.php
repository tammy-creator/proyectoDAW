
<?php $__env->startSection('content'); ?>
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="row">
              <div class="col-md-12">
                <div class="card">

                  <?php if(session('success')): ?>
                  <div class="alert alert-success" role="success">
                    <?php echo e(session('success')); ?>

                  </div>
                  <?php endif; ?>
                  <?php if(session('error')): ?>
                  <div class="alert alert-danger" role="danger">
                    <?php echo e(session('error')); ?>

                  </div>
                  <?php endif; ?>
                  
                  <div class="card-header card-header-primary">
                    <h4 class="card-title">Productos</h4>
                    <p class="card-category">Productos vendidos</p>
                  </div>
                  <div class="card-body">                   
                    
                    <div class="table-responsive">
                      <table class="table">
                        <thead class="text-primary">
                          
                            <th>ID</th>
                            <th>Usuario</th>
                            <th>Fecha compra</th>
                            <th>Producto</th>                            
                            <th>Precio</th> 
                            <th>Cantidad</th>   
                            <th>Ingreso Total</th>                        
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                              <?php if(auth()->user()->roles()->first()->id == PR_ROL_ADMINISTRADOR_ID): ?>
                                <?php if($venta->user_id == $user->id): ?>                               
                                <tr>
                                  <td><?php echo e($venta->id); ?></td>
                                  <td><?php echo e($user->name); ?></td>
                                  <td><?php echo e($venta->created_at->diffForHumans()); ?></td>
                                  <td><?php echo e($venta->producto_name); ?></td>
                                  <td><?php echo e($venta->precio); ?></td>  
                                  <td><?php echo e($venta->cantidad); ?></td>  
                                  <td><?php echo e($venta->precio * $venta->cantidad); ?> €</td>                                 
                                </tr>
                                <?php endif; ?>
                              <?php endif; ?>
                              <?php if(auth()->user()->roles()->first()->id == PR_ROL_TERAPEUTA_ID): ?>
                                <?php if($venta->user_id == $user->id && auth()->user()->id == $user->terapeuta_id): ?> 
                                  <tr>
                                    <td><?php echo e($venta->id); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($venta->created_at->diffForHumans()); ?></td>
                                    <td><?php echo e($venta->producto_name); ?></td>
                                    <td><?php echo e($venta->precio); ?></td>  
                                    <td><?php echo e($venta->cantidad); ?></td>  
                                    <td><?php echo e($venta->precio * $venta->cantidad); ?> €</td>                                 
                                  </tr>
                                <?php endif; ?>
                              <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div class="card-footer mr-auto">
                    <?php echo e($ventas->links()); ?> 
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['activePage' => 'ventas', 'titlePage' => 'Productos Vendidos'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto\proyecto\resources\views/ventas/index.blade.php ENDPATH**/ ?>