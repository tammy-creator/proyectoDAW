
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-primary">
                        <div class="card-title">Productos</div>
                        <p class="card-category">Vista detallada del producto <?php echo e($producto->name); ?></p>
                    </div>
                    <!--body-->
                    <div class="card-body">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success" role="success">
                            <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="row">
                        <div class="col-md-6">
                            <div class="card card-user">
                            <div class="card-body">
                                <p class="card-text">
                                <div class="author">
                                    <a href="#">
                                    <img src="<?php echo e($producto->imageSrc); ?>" alt="image" class="avatar">
                                    <h5 class="title mt-3"><?php echo e($producto->name); ?></h5>
                                    </a>
                                    <p class="description">                                   
                                    Precio: <?php echo e($producto->precio); ?> € <br>                                   
                                    </p>
                                </div>
                                </p>
                                <div class="card-description">
                                    Descripción: <?php echo e($producto->descripcion); ?> <br>
                                </div>
                            </div>
                            <div class="card-footer">
                                
                                <div class="button-container">
                                    <a href="<?php echo e(route('productos.index')); ?>" class="btn btn-primary mr-3"> Volver </a>
                                    <a href="<?php echo e(route('productos.edit', $producto->id)); ?>" class="btn btn-primary">Editar</a>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
                    
<?php echo $__env->make('layouts.main', ['activePage' => 'productos', 'titlePage' => 'Detalles del producto'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto\proyecto\resources\views/productos/show.blade.php ENDPATH**/ ?>