

<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="list-group">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item"><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
          <?php endif; ?>
          <form method="post" action="<?php echo e(route('users.update', $user->id)); ?>" class="form-horizontal">
            <?php echo csrf_field(); ?>           
            <?php echo method_field('PUT'); ?>
            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Usuario')); ?></h4>
                <p class="card-category"><?php echo e(__('Modificar datos')); ?></p>
              </div>

              <div class="card-body ">
                <div class="row">
                  <label for="name" class="col-sm-2 col-form-label"><?php echo e(__('Nombre')); ?></label>
                  <div class="col-sm-7">
                    <input class="form-control" name="name" type="text" value="<?php echo e(old('name', $user->name)); ?>" autofocus/>                      
                    <?php if($errors->has('name')): ?>
                      <span class="error text-danger" for="input-name"><?php echo e($errors->first('name')); ?></span>
                    <?php endif; ?>                  
                  </div>
                </div>

                <div class="row">
                  <label for="apellidos" class="col-sm-2 col-form-label"><?php echo e(__('Apellidos')); ?></label>
                  <div class="col-sm-7">
                    <input class="form-control" name="apellidos" type="text" value="<?php echo e(old('apellidos', $user->apellidos)); ?>"/>                      
                    <?php if($errors->has('apellidos')): ?>
                      <span class="error text-danger" for="input-apellidos"><?php echo e($errors->first('apellidos')); ?></span>
                    <?php endif; ?>
                  </div>
                </div>

                <div class="row">
                  <label for="direccion" class="col-sm-2 col-form-label"><?php echo e(__('Dirección')); ?></label>
                  <div class="col-sm-7">
                    <input class="form-control" name="direccion" type="text" value="<?php echo e(old('direccion', $user->direccion)); ?>"/>                      
                    <?php if($errors->has('direccion')): ?>
                      <span class="error text-danger" for="input-direccion"><?php echo e($errors->first('direccion')); ?></span>
                    <?php endif; ?>
                  </div>
                </div>

                <div class="row">
                  <label for="telefono" class="col-sm-2 col-form-label"><?php echo e(__('Teléfono')); ?></label>
                  <div class="col-sm-7">
                    <input class="form-control" name="telefono" type="text" value="<?php echo e(old('telefono',$user->telefono)); ?>"/>                      
                    <?php if($errors->has('telefono')): ?>
                      <span class="error text-danger" for="input-telefono"><?php echo e($errors->first('telefono')); ?></span>
                    <?php endif; ?>
                  </div>
                </div>

                <div class="row">
                  <label for="email" class="col-sm-2 col-form-label"><?php echo e(__('Email')); ?></label>
                  <div class="col-sm-7">
                    <input type="mail" class="form-control" name="email"  value="<?php echo e(old('email', $user->email)); ?>"/>                      
                    <?php if($errors->has('email')): ?>
                      <span class="error text-danger" for="input-email"><?php echo e($errors->first('email')); ?></span>
                    <?php endif; ?>
                  </div>
                </div>

                <div class="row">
                  <label for="password" class="col-sm-2 col-form-label"><?php echo e(__('Password')); ?></label>
                  <div class="col-sm-7">
                    <input type="password" class="form-control" name="password" placeholder="Ingrese la contraseña solo en caso de querer modificarla" />                      
                    <?php if($errors->has('password')): ?>
                      <span class="error text-danger" for="input-password"><?php echo e($errors->first('password')); ?></span>
                    <?php endif; ?>
                  </div>
                </div>

                <div class="row">
                  <label for="role" class="col-sm-2 col-form-label"><?php echo e(__('Rol')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group">                 
                      <select class="form-control " data-style="btn btn-link" id="role_id" name="role_id">
                        <option value="">Asignar Rol al usuario</option>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php echo e($selected =  $user->roles->contains($id) ? ' selected' : ''); ?>

                          <option value="<?php echo e($id); ?>"<?php echo e($selected); ?>><?php echo e($role); ?></option>                          
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>             
                      </select>
                   </div>
                  </div>
                </div>

                <div class="row">
                  <label for="terapeuta" class="col-sm-2 col-form-label"><?php echo e(__('Terapeuta')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group">                
                      <select class="form-control " data-style="btn btn-link" id="terapeuta_id" name="terapeuta_id">
                        <option value="">Asignar Terapeuta al usuario</option>
                          <?php $__currentLoopData = $terapeutas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $terapeuta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                            <?php echo e($selected =  ($user->terapeuta_id == $terapeuta->id) ? ' selected' : ''); ?>                                            
                            <option value="<?php echo e($terapeuta->id); ?>"<?php echo e($selected); ?>><?php echo e($terapeuta->name); ?></option>                                                
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>               
                      </select>
                   </div>
                  </div>
                </div>

              <div class="card-footer ml-auto mr-auto">
                <button type="submit" class="btn btn-primary"><?php echo e(__('Actualizar Usuario')); ?></button>
                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary mr-3"> Volver </a>
              </div>
            </div>
          </form>
        </div>
      </div>      
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['activePage' => 'users', 'titlePage' => __('Editar usuario')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto\proyecto\resources\views/users/edit.blade.php ENDPATH**/ ?>