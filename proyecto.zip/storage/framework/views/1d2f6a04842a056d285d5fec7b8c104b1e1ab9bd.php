
<?php $__env->startSection('content'); ?>
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-body">

                    <?php if(session('success')): ?>
                    <div class="alert alert-success" role="success">
                      <?php echo e(session('success')); ?>

                    </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                    <div class="alert alert-danger" role="danger">
                      <?php echo e(session('error')); ?>

                    </div>
                    <?php endif; ?>                    
                    
                    <div class="alert alert-danger" id="error" style="display:none"></div>
                    <div class="alert alert-success" id="message" style="display:none"></div>

                  <div class="card-header card-header-primary">
                    <h4 class="card-title">Usuarios</h4>
                    <p class="card-category">Usuarios registrados</p>
                  </div>
                  
                    <div class="row">
                      <div class="col-12 text-right">
                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_create')): ?>
                        <a href="<?php echo e(route('users.create')); ?>" class="btn btn-sm btn-primary">Añadir usuario</a>
                      <?php endif; ?> 
                      </div>
                    </div>
                    <div class="table-responsive">
                      <table class="table">
                        <thead class="text-primary">
                          <?php if(auth()->user()->roles()->first()->id == PR_ROL_TERAPEUTA_ID): ?>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Apellidos</th>
                            <th>Dirección</th>
                            <th>Teléfono</th>
                            <th>Email</th>
                            <th class="text-right">Acciones</th>
                          <?php else: ?>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Apellidos</th>                           
                            <th>Rol</th> 
                            <th>Terapeuta</th>
                            <th class="text-right">Acciones</th>
                          <?php endif; ?>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="row-id-<?php echo e($user->id); ?>">
                              <?php if(auth()->user()->roles()->first()->id == PR_ROL_TERAPEUTA_ID): ?>
                                <?php if(auth()->user()->id == $user->terapeuta_id): ?>
                                <td><?php echo e($user->id); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->apellidos); ?></td>
                                <td><?php echo e($user->direccion); ?></td>
                                <td><?php echo e($user->telefono); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td class="td-actions text-right">
                                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_show')): ?> 
                                    <a href="<?php echo e(route('users.show', $user->id)); ?>" class="btn btn-info"><i class="material-icons">person</i></a>
                                  <?php endif; ?>
                                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_edit')): ?>
                                    <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-warning"><i class="material-icons">edit</i></a>
                                  <?php endif; ?> 
                                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_destroy')): ?>
                                    <button class="btn btn-danger modal_link" type="submit" rel="tooltip" data-id="<?php echo e($user->id); ?>">
                                      <i class="material-icons">close</i>
                                    </button>
                                  <?php endif; ?> 
                                  </td>
                                <?php endif; ?>
                              <?php else: ?>
                                <td><?php echo e($user->id); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->apellidos); ?></td>
                                <td>
                                    <?php $__empty_1 = true; $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <span class="badge badge-info"><?php echo e($role->name); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <span class="badge badge-danger">Sin rol</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($user->terapeuta); ?></td>
                                <td class="td-actions text-right">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_show')): ?> 
                                  <a href="<?php echo e(route('users.show', $user->id)); ?>" class="btn btn-info"><i class="material-icons">visibility</i></a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_edit')): ?>
                                  <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-warning"><i class="material-icons">edit</i></a>
                                <?php endif; ?> 
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_destroy')): ?>                                  
                                  <button class="btn btn-danger modal_link" type="submit" rel="tooltip" data-id="<?php echo e($user->id); ?>">
                                  <i class="material-icons">close</i>
                                  </button>                                  
                                <?php endif; ?> 
                                </td>
                              <?php endif; ?> 
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div class="card-footer mr-auto">
                    <?php echo e($users->links()); ?> 
                  </div>
                  
                  <div id="confirm" class="modal" tabindex="-1" role="dialog">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Eliminar Usuario</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <p>¿Estas seguro de eliminar al usuario?</p>
                        </div>
                        <div class="modal-footer">
                          <button id="btnConfirm" type="button" class="btn btn-primary">Eliminar</button>
                          <button type="button" class="btn btn-secondary" data-dismiss="modal" >Cancelar</button>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('bottomJs'); ?>
<script>
  $(document).on('click',".modal_link",function(){
    $('#error').text('').hide();
    $('#message').text('').hide();
    $("#confirm").modal('show');
    $('#btnConfirm').data('id-delete', $(this).data('id'));
  });
    $(document).on('click',"#btnConfirm",function(){                
              
              let user_id = $(this).data('id-delete');
              if(!$.isNumeric(user_id)) {
                console.error("Error, no se puede enviar un delete a un id vacio");
                return;
              }
              let urlDelete = "<?php echo e(url('users/:id')); ?>".replace(":id", user_id);
              console.log("Vamos a llamar a", urlDelete);
              $.ajax(urlDelete, {
                method: 'delete',
                data: {
                  _token: "<?php echo e(csrf_token()); ?>"
                }
              }).done(function(res) {
                $('#confirm').modal('hide');
                if(res['status'] === undefined) {
                  $('#error').text("Error interno borrando usuario").show();
                  
                  return;
                }
                if(res.status == 1) {
                  $('#message').text(res.message).show();
                  $('#row-id-' + user_id).remove()
                }
                else {
                  $('#error').text(res.message).show();
                }
               
              }).fail(function(xhr) {
                console.error(xhr);
              });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['activePage' => 'users', 'titlePage' => 'Usuarios'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto\proyecto\resources\views/users/index.blade.php ENDPATH**/ ?>