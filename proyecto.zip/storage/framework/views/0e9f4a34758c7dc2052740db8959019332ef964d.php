<div class="sidebar" data-color="purple" data-background-color="white" data-image="<?php echo e(asset('material')); ?>/img/sidebar-1.jpg">
  <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
  <div class="logo">
    <a href="https://www.centroproyecta.es" class="simple-text logo-normal">
      <i><img style="width:200px" src="<?php echo e(asset('material')); ?>/img/LOGOazul.png"></i>
    </a>
  </div>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item<?php echo e($activePage == 'dashboard' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
          <i class="material-icons">dashboard</i>
            <p><?php echo e(__('Dashboard')); ?></p>
        </a>
      </li>
      
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_index')): ?>
       <li class="nav-item<?php echo e($activePage == 'users' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
          <i class="material-icons">content_paste</i>
            <p><?php echo e(__('Usuarios')); ?></p>
        </a>
      </li> 
      <?php endif; ?>
      
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_index')): ?>      
      <li class="nav-item<?php echo e($activePage == 'permissions' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('permissions.index')); ?>">
          <i class="material-icons">library_books</i>
            <p><?php echo e(__('Permisos')); ?></p>
        </a>
      </li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_index')): ?>
      <li class="nav-item<?php echo e($activePage == 'roles' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('roles.index')); ?>">
          <i class="material-icons">bubble_chart</i>
          <p><?php echo e(__('Roles')); ?></p>
        </a>
      </li>
      <?php endif; ?>
     
      <?php if((auth()->user()->roles()->first()->id == PR_ROL_USUARIO_ID && auth()->user()->terapeuta_id != null) || auth()->user()->roles()->first()->id == PR_ROL_TERAPEUTA_ID || auth()->user()->roles()->first()->id == PR_ROL_ADMINISTRADOR_ID): ?>
        <li class="nav-item<?php echo e($activePage == 'evento' ? ' active' : ''); ?>">
          <a class="nav-link" href="<?php echo e(route('evento.index')); ?>">
            <i class="material-icons">today</i>
              <p><?php echo e(__('Calendario')); ?></p>
          </a>
        </li>
      <?php endif; ?>     
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('producto_index')): ?>
       <li class="nav-item<?php echo e($activePage == 'productos' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('productos.index')); ?>">
          <i class="material-icons">shopping_bag</i>
          <p><?php echo e(__('Productos')); ?></p>
        </a>
      </li>
      <?php endif; ?>
     
      <li class="nav-item<?php echo e($activePage == 'tienda' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('tienda.index')); ?>">
          <i class="material-icons">shopping_cart</i>
          <p><?php echo e(__('Tienda')); ?></p>
        </a>
      </li> 
     
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_create')): ?>
      <li class="nav-item<?php echo e($activePage == 'ventas' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('ventas.index')); ?>">
          <i class="material-icons">store</i>
          <p><?php echo e(__('Ventas')); ?></p>
        </a>
      </li>
      <?php endif; ?>     
    </ul>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\proyecto\proyecto\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>