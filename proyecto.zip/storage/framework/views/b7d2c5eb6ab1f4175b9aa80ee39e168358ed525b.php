<?php session_start();?>

<?php $__env->startSection('content'); ?>


    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="row">
              <div class="col-md-12">
                <div class="card">

                  <?php if(session('success')): ?>
                    <div class="alert alert-success" role="success">
                      <?php echo e(session('success')); ?>

                    </div>
                  <?php endif; ?>
                  <?php if(session('error')): ?>
                    <div class="alert alert-danger" role="danger">
                      <?php echo e(session('error')); ?>

                    </div>
                  <?php endif; ?> 

                  <div class="card-header card-header-primary">
                    <h4 class="card-title">Tienda</h4>
                    <p class="card-category">Comprar productos</p>
                  </div>
                  <div class="card-body">                   

                    
                    <div class="container mt-5">
                        <div class="row" style="justify-content;">

                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <div class="card m-4" style="width: 10rem;">
                                <form id="formulario" name="formulario" method="post" action="cart.php">
                                    <input name="precio" type="hidden" id="precio" value="<?php echo e($producto->precio); ?>" />
                                    <input name="name" type="hidden" id="name" value="<?php echo e($producto->name); ?>" />
                                    <input name="cantidad" type="hidden" id="cantidad" value="1" class="pl-2" />                                    
                                    <div class="card-body">
                                        <h5 class="card-title text-center"><strong>  <?php echo e($producto->name); ?> </strong></h5>
                                        <img src="<?php echo e($producto->imageSrc); ?>" class="card-img-top" alt="imagen producto" width="10">
                                        <p class="card-text"><?php echo e($producto->descripcion); ?> </p>
                                        <p class="card-text">Precio: <?php echo e($producto->precio); ?></p>
                                        <a href="<?php echo e(route('tienda.addCarrito', $producto->id)); ?>" class="btn btn-primary"><i class="material-icons">shopping_cart</i> Comprar</a>
                                    </div>
                                    
                                </form>
                            </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                        </div>
                    </div>
                  <div class="card-footer mr-auto">
                   
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', ['activePage' => 'tienda', 'titlePage' => 'Tienda'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto\proyecto\resources\views/tienda/index.blade.php ENDPATH**/ ?>