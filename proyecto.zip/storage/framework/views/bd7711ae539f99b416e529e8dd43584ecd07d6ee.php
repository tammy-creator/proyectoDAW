<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
  <div class="container-fluid">
    <div class="navbar-wrapper">
      <a class="navbar-brand" href="#"></a>
    </div>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsingNavbar" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
    <span class="sr-only">Toggle navigation</span>
    <span class="navbar-toggler-icon icon-bar"></span>
    <span class="navbar-toggler-icon icon-bar"></span>
    <span class="navbar-toggler-icon icon-bar"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end" id="collapsingNavbar" >
      
      
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('home')); ?>">
                <i class="material-icons">dashboard</i>
                <p class="d-lg-none d-md-block">
                  <?php echo e(__('Stats')); ?>

                </p>
              </a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="material-icons">notifications</i>
                
                  <?php if(count(auth()->user()->unreadNotifications)): ?>
                    <span class="notification">
                     <?php echo e(count(auth()->user()->unreadNotifications)); ?>

                    </span>                    
                  <?php endif; ?>
                
                <p class="d-lg-none d-md-block">
                  <?php echo e(__('Some Actions')); ?>

                </p>
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                <?php $__currentLoopData = auth()->user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($notification->type == 'App\Notifications\EventoNotification'): ?>
                    <a class="dropdown-item" href="<?php echo e(route('evento.index')); ?>">
                      <i class="mr-2">Nueva Cita: <?php echo e($notification->data['user_name']); ?></i>
                      <span class="pull-right text-muted text-sm"><?php echo e($notification->created_at->diffForHumans()); ?></span>
                    </a>
                  <?php else: ?>
                    <a class="dropdown-item" href="<?php echo e(route('users.index')); ?>">
                      <i class="mr-2">Nuevo usuario registrado <?php echo e($notification->data['user_name']); ?></i>
                      <span class="pull-right text-muted text-sm"><?php echo e($notification->created_at->diffForHumans()); ?></span>
                    </a>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
              </div>
            </li>
            
            <li class="nav-item">
              <a class="nav-link" id="modal_cart_link" href="#modal_cart" data-bs-toggle="modal" data-bs-target="#modal_cart">
                <i class="material-icons"> shopping_cart</i>
              </a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link" href="#pablo" id="navbarDropdownProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="material-icons">person</i>
                <p class="d-lg-none d-md-block">
                  <?php echo e(__('Account')); ?>

                </p>
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
                <a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>"><?php echo e(__('Mi Perfil')); ?></a>
                
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();"><?php echo e(__('Salir')); ?></a>
              </div>
            </li>
          </ul>
       
    </div>
  </div>
</nav>

 <!-- MODAL CARRITO -->
 <div class="modal fade bd-example-modal-lg" id="modal_cart" tabindex="-1"  aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Carrito Compra</h5>
      </div>
      <div class="modal-body">

        <?php $valor = 0 ?>

        <?php if(session('cart')): ?>

        <div class="table-responsive">
          <table class="table table-shopping">
            <thead class="text-primary">
              <tr>
                <th class="text-center"></th>
                <th class="hide"></th>
                <th class="text-center">Producto</th>
                <th class="text-center">Precio</th>
                <th class="text-center">Cantidad</th>
                <th class="text-center">Precio Total</th>
                <th></th>
              </tr>              
            </thead>
            <tbody>
              
              <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$detalles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
                <?php
                  $valor += $detalles['precio'] * $detalles['cantidad']
                ?>
                    <tr class="text-center" scope="row" id="rowItem-<?php echo e($id); ?>" >
                      <td>
                        <div class="img-container">
                          <img src="<?php echo e($detalles['foto']); ?>" class="card-img-top w-25" alt="imagen producto">
                        </div>
                      </td> 
                      <td class="hide"><?php echo e($id); ?></td>        
                      <td class="text-center"><?php echo e($detalles['name']); ?></td>
                      <td class="text-center"><?php echo e($detalles['precio']); ?></td>
                      <td class="text-center" id="quantity-<?php echo e($id); ?>" data-quantity="<?php echo e($detalles['cantidad']); ?>"><?php echo e($detalles['cantidad']); ?></td>
                      <td class="text-center" id="price-<?php echo e($id); ?>" data-value="<?php echo e($detalles['precio'] * $detalles['cantidad']); ?>"><?php echo e($detalles['precio'] * $detalles['cantidad']); ?> </td>
                      <td>
                        <div class="btn-group">
                          <button class="btn btn-round btn-primary btn-sm removeItem" data-id="<?php echo e($id); ?>"> <i class="material-icons">remove</i> </button>
                          <button class="btn btn-round btn-primary btn-sm addItem" data-id="<?php echo e($id); ?>"> <i class="material-icons">add</i> </button>
                        </div>
                      </td>
                    </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>   

			  <?php endif; ?>
          <table class="align-right">
            <th>
              <div class="badge text-wrap" style=" width: 10rem;">
                <h3 > Total: <span id="total"><?php echo e($valor); ?></span> €</h3>
              </div>
            </th>
          </table>
      </div>
      <div class="modal-footer">
        <a href="<?php echo e(route ('tienda.index')); ?>" class="btn btn-warning btn-sm">Cerrar</a>
        <a class="btn btn-primary btn-sm" id="btnRemove">Vaciar carrito</a>
        <a class="btn btn-success btn-sm" id="btnCompra">Finalizar compra</a>
      </div>
    </div>
  </div>
</div>
<!-- END MODAL CARRITO -->
<?php $__env->startSection('bottomJs'); ?>
<script>
    $(document).on('click',"#modal_cart_link",function(){
               $("#modal_cart").modal('show');
    });
    $(document).on('click',"#btnRemove",function(){
                
              let urlDelete = "<?php echo e(route('tienda.remove')); ?>";
              
              
              $.ajax(urlDelete, {
                method: 'delete',
                data: {
                  _token: "<?php echo e(csrf_token()); ?>"
                }
              }).done(function() {
                $('#message').text("Carrito vaciado correctamente").show();
                $('#modal_cart').modal('hide');
                location.reload();
              }).fail(function(xhr) {
                console.error(xhr);
              });
    });
    $(document).on('click',"#btnCompra",function(){    
              let url = "<?php echo e(route('ventas.store')); ?>";
             
              $.ajax(url, {
                method: 'post',
                data: {
                  
                  _token: "<?php echo e(csrf_token()); ?>"
                }
              }).done(function() {
           
                $('#message').text("Compra realizada correctamente").show();
                $('#modal_cart').modal('hide');
                location.reload();
              }).fail(function(xhr) {
                console.error(xhr);
              });
               
      });

      
      $(document).on('click',".removeItem",function(){   
        console.log('clicado menos');
        let id = $(this).data('id');
        let newQuantity = $('#quantity-' + id).data('quantity') - 1;
        let price = $('#price-' + id).data('value');
        
        cambiarCantidad(id, newQuantity, price);
        
      });
      $(document).on('click',".addItem",function(){   
        console.log('clicado mas');
        let id = $(this).data('id');
        let newQuantity = $('#quantity-' + id).data('quantity') + 1;
        let price = $('#price-' + id).data('value');
        cambiarCantidad(id, newQuantity, price);
      });

      function cambiarCantidad(id, cant, price) {
        console.log(arguments);
        let newRoute = "<?php echo e(url('tienda/carritoCambio')); ?>/:id/:quant";
        newRoute = newRoute.replace(":id", id).replace(':quant', cant);
        console.log("Vamos a llamar a ", newRoute);
        $.ajax(newRoute, {
          method: 'get',
          dataType: 'json',
        }).done(function(res) {
          console.log(res);
          if(res.newQuantity == 0) {
            $('#rowItem-' + id).remove();
            $('#total').text(0);
            return;
          }
          $('#price-' + id).data('value', res.newPrice);
          $('#price-' + id).text(res.newPrice);
          $('#total').text(res.total);
          $('#quantity-' + id).text(res.newQuantity).data('quantity', res.newQuantity);
        }).fail(function(err) {

        });
      } 
    

    
</script>
<?php $__env->stopSection(); ?>


<?php /**PATH C:\xampp\htdocs\proyecto\proyecto\resources\views/layouts/navbars/navs/auth.blade.php ENDPATH**/ ?>