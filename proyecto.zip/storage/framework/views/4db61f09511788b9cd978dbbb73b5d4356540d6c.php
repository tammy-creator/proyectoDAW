
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-primary">
                        <div class="card-title">Role</div>
                        <p class="card-category">Vista detallada del Rol <?php echo e($role->name); ?></p>
                    </div>
                    <!--body-->
                    <div class="card-body">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success" role="success">
                            <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="row">
                        <div class="col-md-6">
                            <div class="card card-user">
                            <div class="card-body">
                                <p class="card-text">
                                <div class="author">
                                    <a href="#">
                                    <img src="<?php echo e(asset('/material/img/astronauta.jpg')); ?>" alt="image" class="avatar">
                                    <h5 class="title mt-3">Rol:    <?php echo e($role->name); ?></h5>
                                    </a>                                    
                                </div>
                                </p> 
                                <div class="card-description">
                                    <h5 class="title mt-3">Permisos Asignados:</h5>
                                    <?php $__empty_1 = true; $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <span class="badge rounded-pill bg-dark text-white"><?php echo e($permission->name); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <span class="badge badge-danger bg-danger">No permissions</span>
                                    <?php endif; ?> 
                                </div>                             
                            </div>
                            <div class="card-footer">                                
                                <div class="button-container">
                                    <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-primary mr-3"> Volver </a>
                                    <a href="<?php echo e(route('roles.edit', $role->id)); ?>" class="btn btn-primary">Editar</a>
                                </div>
                            </div>                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
                    
<?php echo $__env->make('layouts.main', ['activePage' => 'roles', 'titlePage' => 'Detalles del Rol'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto\proyecto\resources\views/roles/show.blade.php ENDPATH**/ ?>