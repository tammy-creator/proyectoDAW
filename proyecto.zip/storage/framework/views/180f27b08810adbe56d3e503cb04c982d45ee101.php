
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">

                    <?php if(session('success')): ?>
                        <div class="alert alert-success" role="success">
                        <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                
                    <div class="card-header card-header-primary">
                        <div class="card-title">Usuarios</div>
                        <p class="card-category">Vista detallada del usuario <?php echo e($user->name); ?></p>
                    </div>
                    <!--body-->
                    <div class="card-body">
                       
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card card-user">
                                    <div class="card-body">
                                        <p class="card-text">
                                        <div class="author">
                                            <a href="#">
                                            <img src="<?php echo e(asset('/material/img/default-avatar.png')); ?>" alt="image" class="avatar">
                                            <h5 class="title mt-3"><?php echo e($user->name); ?></h5>
                                            </a>
                                            <p class="description">                                   
                                            Apellidos: <?php echo e($user->apellidos); ?> <br>
                                            Dirección: <?php echo e($user->direccion); ?> <br>
                                            Teléfono: <?php echo e($user->telefono); ?> <br>
                                            Email:<?php echo e($user->email); ?> <br>  
                                            Rol:
                                            <?php $__empty_1 = true; $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <span class="badge rounded-pill bg-dark text-white"><?php echo e($role->name); ?></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <span class="badge badge-danger bg-danger">No roles</span>
                                            <?php endif; ?>                                  
                                            
                                            </p>
                                        </div>
                                        </p>
                                        <div class="card-description">
                                        
                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        
                                        <div class="button-container">
                                            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary mr-3"> Volver </a>
                                            <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-primary">Editar</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
                    
<?php echo $__env->make('layouts.main', ['activePage' => 'users', 'titlePage' => 'Detalles del usuario'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto\proyecto\resources\views/users/show.blade.php ENDPATH**/ ?>