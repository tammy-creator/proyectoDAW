<?php
define("PR_LAST_CHANGE", "20211113");
define("PR_ROL_TERAPEUTA_ID", 2);
define("PR_ROL_ADMINISTRADOR_ID", 1);
define("PR_ROL_USUARIO_ID", 3);
